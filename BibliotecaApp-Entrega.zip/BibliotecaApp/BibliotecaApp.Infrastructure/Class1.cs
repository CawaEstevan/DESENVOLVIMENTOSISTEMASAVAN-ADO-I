﻿namespace BibliotecaApp.Infrastructure;

public class Class1
{

}
