﻿namespace BibliotecaApp.Domain;

public class Class1
{

}
