﻿namespace BibliotecaApp.Application;

public class Class1
{

}
